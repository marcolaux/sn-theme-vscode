# vscode-theme

A theme for Standard Notes inspired by the VS Code Dark theme.

How to install:

- Open the Extensions manager on the Desktop or [Web client](https://app.standardnotes.org), located in the bottom left corner.
- Click `Import Extension`
- Paste in: <https://raw.githubusercontent.com/hyphone/sn-theme-vscode/master/ext.json>
- Hit Enter/Return

![screenshot](https://github.com/hyphone/sn-theme-vscode/raw/master/screenshot.png)
